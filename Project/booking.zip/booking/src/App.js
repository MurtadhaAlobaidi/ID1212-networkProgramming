import './App.css'

import NavbarCom from './components/NavbarCom'

function App() {
  return (
    <div><NavbarCom/></div>
  )
}

export default App

import React from 'react'

export const About = () => {
  return (
    <div>
      <h1>About oss</h1>
    </div>
  )
}

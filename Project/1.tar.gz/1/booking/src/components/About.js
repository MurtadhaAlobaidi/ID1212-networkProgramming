import React from "react";

export const About = () =>{
    return(
        <div><h1>About peage</h1></div>
    )
}
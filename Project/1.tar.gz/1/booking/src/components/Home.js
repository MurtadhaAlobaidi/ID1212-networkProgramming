import React from "react";

export const Home = () =>{
    return(
        <div><h1>Home peage</h1></div>
    )
}
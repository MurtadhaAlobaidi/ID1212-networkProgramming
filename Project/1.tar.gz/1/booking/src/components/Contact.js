import React from "react";

export const Contact = () =>{
    return(
        <div><h1>Contact peage</h1></div>
    )
}